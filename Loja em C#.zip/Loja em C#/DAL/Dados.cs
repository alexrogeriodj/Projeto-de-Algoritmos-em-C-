using System;
using System.Collections.Generic;
using System.Text;

namespace Loja.DAL
{
    class Dados
    {

        public static string StringDeConexao
        {
            get
            {
                return "Use a sua string de conex�o aqui.";
            }
        }

    }
}
